#!/bin/bash
# Установка «Вася Куларесов — сервер» на Ubuntu / Debian (VPS). Запуск от root:  bash install.sh
# Ставит Node.js 20, копирует программу в /opt/vasya, спрашивает настройки и включает службу:
# работает круглосуточно, сама запускается после перезагрузки сервера и перезапускается при сбое.
set -e
DIR=/opt/vasya
HERE="$(cd "$(dirname "$0")" && pwd)"
[ "$(id -u)" = 0 ] || { echo "Запустите от root: sudo bash install.sh"; exit 1; }

echo "== 1/4 Node.js"
command -v curl >/dev/null && command -v openssl >/dev/null || { apt-get update -y && apt-get install -y curl ca-certificates openssl; }
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  apt-get update -y && apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
node -v

# сертификаты Минцифры (Russian Trusted Root/Sub CA) в системе сервера не нужны (программа доверяет им только для API
# Т-Инвестиций, у себя внутри): если хостинг подложил их в системное хранилище — убираем
RU_FOUND=0
for f in /usr/local/share/ca-certificates/*.crt /usr/local/share/ca-certificates/*/*.crt /usr/share/ca-certificates/*/*.crt; do
  [ -f "$f" ] || continue
  if openssl x509 -in "$f" -noout -subject 2>/dev/null | grep -qi "Russian Trusted"; then
    echo "Удаляю сертификат Минцифры из системы: $f"; rm -f "$f"; RU_FOUND=1
  fi
done
[ -f /etc/ca-certificates.conf ] && sed -i '/[Rr]ussian/d' /etc/ca-certificates.conf
if [ "$RU_FOUND" = 1 ]; then update-ca-certificates --fresh >/dev/null 2>&1 || true; fi
if grep -qi "Russian Trusted" /etc/ssl/certs/ca-certificates.crt 2>/dev/null; then echo "ВНИМАНИЕ: сертификат Минцифры остался в /etc/ssl/certs — программа системные сертификаты не использует"; fi
rm -f "$DIR/data/ru_trusted_ca.pem"

# сертификаты Минцифры — ТОЛЬКО для программы и только для API Т-Инвестиций (у их сервера российский сертификат):
# скачиваем с Госуслуг в $DIR/certs, сверяем отпечатки SHA-256; в систему сервера НЕ устанавливаем
mkdir -p "$DIR/certs"
getca() { # $1 — файл, $2 — адрес, $3 — отпечаток
  local f="$DIR/certs/$1"
  if [ -f "$f" ] && [ "$(openssl x509 -in "$f" -noout -fingerprint -sha256 2>/dev/null | cut -d= -f2)" = "$3" ]; then return 0; fi
  curl -fsSL --max-time 30 "$2" -o "$f.tmp" 2>/dev/null || { rm -f "$f.tmp"; return 1; }
  openssl x509 -in "$f.tmp" -out "$f.tmp2" 2>/dev/null || openssl x509 -inform DER -in "$f.tmp" -out "$f.tmp2" 2>/dev/null
  if [ "$(openssl x509 -in "$f.tmp2" -noout -fingerprint -sha256 2>/dev/null | cut -d= -f2)" = "$3" ]; then mv "$f.tmp2" "$f"; rm -f "$f.tmp"; return 0; fi
  rm -f "$f.tmp" "$f.tmp2"; return 1
}
if getca russian_trusted_root_ca.pem https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt D2:6D:2D:02:31:B7:C3:9F:92:CC:73:85:12:BA:54:10:35:19:E4:40:5D:68:B5:BD:70:3E:97:88:CA:8E:CF:31 \
 && getca russian_trusted_sub_ca.pem https://gu-st.ru/content/lending/russian_trusted_sub_ca_pem.crt BB:BD:E2:10:3E:79:0B:99:9E:C6:2B:D0:3C:F6:25:A5:A2:E7:C3:16:E1:0A:FE:6A:49:0E:ED:EA:D8:B3:FD:9B; then
  echo "Сертификаты Минцифры для Т-Инвестиций: на месте (только для программы, $DIR/certs)"
else
  echo "Сертификаты Минцифры скачать не удалось — Т-Инвестиции с этого сервера работать не будут (Финам и АЛОР — будут)."
  echo "Вручную: положите russian_trusted_root_ca.pem и russian_trusted_sub_ca.pem (с gosuslugi.ru/crt) в $DIR/certs и: systemctl restart vasya"
fi

echo "== 2/4 Программа → $DIR"
id vasya >/dev/null 2>&1 || useradd --system --home-dir "$DIR" --shell /usr/sbin/nologin vasya
mkdir -p "$DIR/data"
cp "$HERE/vasya-server.js" "$DIR/"
chown -R vasya:vasya "$DIR"
chmod 755 "$DIR/certs" 2>/dev/null; chmod 644 "$DIR/certs/"*.pem 2>/dev/null
chmod 700 "$DIR/data"

echo "== 3/4 Настройки"
echo "Настройки и ключи перенесёт само приложение: ⚙ → Сервер → «Подключить» (адрес и код появятся в конце)."
if [ -f "$DIR/data/config.json" ]; then chown vasya:vasya "$DIR/data/config.json"; chmod 600 "$DIR/data/config.json"; echo "Найден data/config.json — будет применён при запуске."; fi
# порт для приложения: открываем в брандмауэре, если он включён
if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow 8077/tcp >/dev/null && echo "Порт 8077 открыт в ufw"; fi
if command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then firewall-cmd --permanent --add-port=8077/tcp >/dev/null && firewall-cmd --reload >/dev/null && echo "Порт 8077 открыт в firewalld"; fi

echo "== 4/4 Служба"
cp "$HERE/vasya.service" /etc/systemd/system/vasya.service
systemctl daemon-reload
systemctl enable vasya >/dev/null
systemctl restart vasya
sleep 4
systemctl --no-pager --lines=15 status vasya || true
CODE=$(runuser -u vasya -- env VK_DATA="$DIR/data" node "$DIR/vasya-server.js" code 2>/dev/null | sed 's/.*: //')
IP=$(curl -fs4 --max-time 5 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
echo
runuser -u vasya -- env VK_DATA="$DIR/data" node "$DIR/vasya-server.js" check || true
echo
echo "================================================================"
echo "  В приложении: ⚙ → Сервер, впишите и нажмите «Подключить»:"
echo "     Адрес сервера:  $IP"
echo "     Код доступа:    $CODE"
echo "  (код никому не сообщайте; показать снова: sudo cat $DIR/data/access.key)"
echo "  Если не подключается — откройте порт 8077 (TCP) в панели хостинга."
echo "================================================================"
echo
echo "Полезные команды:"
echo "  journalctl -u vasya -f          — что делает сервер (выход: Ctrl+C)"
echo "  systemctl restart vasya         — перезапуск;  systemctl stop vasya — остановить"
