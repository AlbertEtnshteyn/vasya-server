// Посредник для Telegram (Cloudflare Worker) — для серверов, где api.telegram.org закрыт.
// Пропускает только запросы к Bot API (/bot<токен>/...), остальное не трогает.
export default {
  async fetch(req) {
    const u = new URL(req.url);
    if (!/^\/(file\/)?bot\d+:[\w-]+\//.test(u.pathname))
      return new Response('Вася Куларесов: посредник Telegram работает', { headers: { 'content-type': 'text/plain; charset=utf-8' } });
    return fetch(new Request('https://api.telegram.org' + u.pathname + u.search, req));
  },
};
